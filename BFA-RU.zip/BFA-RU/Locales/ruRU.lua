
if GetLocale() ~= "ruRU" then return end
local _, mod = ...
local L = mod.L

L.firstRunWarning = "Таймеры не будут показаны, пока вы не увидите свое первое вторжение."
L.underAttack = "|T236292:15:15:0:0:64:64:4:60:4:60|t %s находится под атакой!"
L.nextInvasions = "Следующее вторжение"
L.next = "Следующее"
L.waiting = "Ожидание"